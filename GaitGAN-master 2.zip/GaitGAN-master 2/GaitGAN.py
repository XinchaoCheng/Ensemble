import tensorflow as tf
import os
from utils import DataReader
import numpy as np
import scipy.misc
from utils import dir_gen


class GaitGAN():
    def __init__(self):
        self.GEI_height = 88
        self.GEI_width = 128
        self.GEI_channel = 1
        self.learning_rate = 1e-7
        self.beta1 = 0.5
        self.max_step = 10000
        self.batch_size = 30
        self.endpoints = {}
        self.input = tf.placeholder(dtype=tf.float32, shape=(None, self.GEI_height, self.GEI_width, self.GEI_channel),
                                    name='input')
        self.input_real_image = tf.placeholder(dtype=tf.float32,
                                               shape=(None, self.GEI_height, self.GEI_width, self.GEI_channel),
                                               name='input_real')
        self.z = self.encoder(self.input)
        self.generated_img = self.generator(self.z)
        self.logits_true_for_d = self.discriminator(self.input, self.input_real_image)
        self.logits_false_for_d = self.discriminator(self.input, self.generated_img, reuse=True)
        self.logits_true_for_g = self.discriminator(self.input, self.generated_img, reuse=True)

        # self.loss_d = tf.softmax_
        self.E_variable = [var for var in tf.trainable_variables() if var.name.startswith("encoder")]
        self.G_variable = [var for var in tf.trainable_variables() if var.name.startswith("generator")]
        self.D_variable = [var for var in tf.trainable_variables() if var.name.startswith("discriminator")]

        self.D_loss = -tf.reduce_mean(tf.log(self.logits_true_for_d) + tf.log(1.0 - self.logits_false_for_d))
        self.EG_loss = -tf.reduce_mean(tf.log(self.logits_true_for_g)) + tf.reduce_mean(tf.losses.absolute_difference(
            self.input_real_image, self.generated_img))*2

        self.D_optimizer = tf.train.AdamOptimizer(self.learning_rate * 0.05, self.beta1)
        self.D_grads_and_vars = self.D_optimizer.compute_gradients(self.D_loss, var_list=self.D_variable)
        self.D_train = self.D_optimizer.apply_gradients(self.D_grads_and_vars)

        self.EG_optimizer = tf.train.AdamOptimizer(self.learning_rate, self.beta1)
        self.EG_grads_and_vars = self.EG_optimizer.compute_gradients(self.EG_loss,
                                                                     var_list=[self.E_variable, self.G_variable])
        self.EG_train = self.EG_optimizer.apply_gradients(self.EG_grads_and_vars)

        self.d_loss_sum = tf.summary.scalar('D_loss', self.D_loss)
        self.sum_eg_loss = tf.summary.scalar('EG_loss', self.EG_loss)
        self.sum_degree_0 = tf.summary.image('degree_0', self.input)
        self.sum_degree_45 = tf.summary.image('degree_45', self.input_real_image)
        self.sum_faked = tf.summary.image('faked', self.generated_img)

        self.summary_op = tf.summary.merge([self.sum_degree_0, self.sum_degree_45, self.sum_faked, self.sum_eg_loss])

    def encoder(self, input, reuse=False):
        with tf.variable_scope('encoder'):
            current = input
            current = tf.layers.conv2d(inputs=current, filters=32, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv1',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn1')

            current = tf.layers.conv2d(inputs=current, filters=64, kernel_size=(5, 5), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv2',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn2')

            current = tf.layers.conv2d(inputs=current, filters=128, kernel_size=(5, 5), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv3',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn3')

            current = tf.layers.conv2d(inputs=current, filters=256, kernel_size=(3, 3), strides=(1, 2), padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv4',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV4'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn4')

            current = tf.reshape(current, (-1, self.GEI_height / 8 * self.GEI_width / 16 * 256))
            current = tf.contrib.layers.fully_connected(current, 128, reuse=reuse, scope='encoder')

            return current

    def generator(self, input, reuse=False):
        with tf.variable_scope('generator'):
            current = input
            current = tf.contrib.layers.fully_connected(current, self.GEI_height / 8 * self.GEI_width / 16 * 256,
                                                        reuse=reuse)
            current = self.lrelu(current)
            current = tf.reshape(current, (-1, self.GEI_height / 8, self.GEI_width / 16, 256))
            current = tf.layers.conv2d_transpose(inputs=current, filters=128, kernel_size=(4, 4), strides=(1, 2),
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv1',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn1')

            current = self.lrelu(current)

            current = tf.layers.conv2d_transpose(inputs=current, filters=64, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv2',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn2')

            current = self.lrelu(current)
            current = tf.layers.conv2d_transpose(inputs=current, filters=32, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv3',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn3')

            current = self.lrelu(current)
            current = tf.layers.conv2d_transpose(inputs=current, filters=1, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv4',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV4'] = current
            # current = tf.layers.batch_normalization(current, reuse=reuse)
            #
            # current = tf.layers.conv2d_transpose(inputs=current, filters=1, kernel_size=(4, 4), strides=2,
            #                                      padding='SAME',
            #                                      use_bias=False, reuse=reuse)
            # self.endpoints['G_DECONV5'] = current
            current = tf.nn.tanh(current)
            return current

    def discriminator(self, input, target, reuse=False):
        with tf.variable_scope('discriminator'):
            current = tf.concat([input, target], axis=3)

            current = tf.layers.conv2d(inputs=current, filters=32, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv1',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn1')
            current = self.lrelu(current)

            current = tf.layers.conv2d(inputs=current, filters=64, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv2',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn2')
            current = self.lrelu(current)

            current = tf.layers.conv2d(inputs=current, filters=128, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv3',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn3')
            current = self.lrelu(current)

            current = tf.layers.conv2d(inputs=current, filters=256, kernel_size=(7, 7), strides=(1, 2), padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv4',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV4'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn4')
            current = self.lrelu(current)

            current = tf.reshape(current, (-1, self.GEI_height / 8 * self.GEI_width / 16 * 256))
            current = tf.contrib.layers.fully_connected(current, 1, reuse=reuse, scope='discriminator')
            current = tf.sigmoid(current)

            return current

    def lrelu(self, x, alpha=0.2):
        return tf.nn.relu(x) - alpha * tf.nn.relu(-x)

    def train(self, k):
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            logdir = dir_gen.dir_gen('./summary')
            self.summary_writer = tf.summary.FileWriter(graph=sess.graph, logdir=logdir)
            self.saver = tf.train.Saver()
            data_reader = DataReader.DataReader()
            for step in range(self.max_step):
                x, y = data_reader.nextBatch(self.batch_size)
                x = np.expand_dims(np.array(x), -1)
                y = np.expand_dims(np.array(y), -1)
                for j in range(k):
                    _, loss_D, sum = sess.run([self.D_train, self.D_loss, self.d_loss_sum],
                                              feed_dict={self.input: x, self.input_real_image: y})
                    print("Step: %d\t Loss_D: %lf\n" % (step, loss_D))
                    self.summary_writer.add_summary(sum, step * k + j)

                _, loss_EG, sum = sess.run([self.EG_train, self.EG_loss, self.summary_op],
                                           feed_dict={self.input: x, self.input_real_image: y})
                print("Step: %d\t Loss_EG: %lf\n" % (step, loss_EG))
                self.summary_writer.add_summary(sum, step)

                # test_x = data_reader.getTestSample()
                # test_x = np.expand_dims(np.array(test_x), -1)
                # test_x = np.expand_dims(np.array(test_x), 0)
                # test_generated = sess.run(self.generated_img, feed_dict={self.input: test_x})
                # if not os.path.exists('./generated'):
                #     os.makedirs('./generated')
                # test_path = "./generated/%05d.jpg" % step
                # test_generated = np.squeeze(test_generated, 0)
                # test_generated = np.squeeze(test_generated, -1)
                # scipy.misc.imsave(test_path, test_generated)
                if (step + 1) % 500 == 0:
                    if not os.path.exists('./model'):
                        os.makedirs('./model')
                    self.saver.save(sess=sess, save_path='./model/GaitGAN', global_step=step)


if __name__ == '__main__':
    model = GaitGAN()
    model.train(1)
