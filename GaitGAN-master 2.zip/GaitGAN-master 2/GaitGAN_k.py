import tensorflow as tf
import os
from utils import DataReader
import numpy as np
import scipy.misc
from utils import dir_gen


class GaitGAN():
    def __init__(self):
        self.GEI_height = 88
        self.GEI_width = 128
        self.GEI_channel = 1
        self.learning_rate = 1e-5
        self.beta1 = 0.5
        self.max_step = 12000
        self.batch_size = 30
        self.endpoints = {}
        self.input = tf.placeholder(dtype=tf.float32, shape=(self.batch_size, self.GEI_height, self.GEI_width, self.GEI_channel),
                                    name='input')
        self.input_real_image = tf.placeholder(dtype=tf.float32,
                                               shape=(self.batch_size, self.GEI_height, self.GEI_width, self.GEI_channel),
                                               name='input_real')

        self.input_label = tf.placeholder(dtype=tf.float32, shape=(self.batch_size, 14), name='input_label')
        self.z = self.encoder(self.input)
        self.generated_img = self.generator(self.z, self.input_label)

        self.logits_true_for_did = self.discriminator_id(self.input, self.input_real_image)
        self.logits_false_for_did = self.discriminator_id(self.input, self.generated_img, reuse=True)
        self.logits_true_for_g_id = self.discriminator_id(self.input, self.generated_img, reuse=True)

        self.logits_true_for_dimg = self.discriminator_img(self.input_real_image, self.input_label)
        self.logits_false_for_dimg = self.discriminator_img(self.generated_img, self.input_label, reuse=True)
        self.logits_true_for_g_img = self.discriminator_img(self.generated_img, self.input_label, reuse=True)

        # self.loss_d = tf.softmax_
        self.E_variable = [var for var in tf.trainable_variables() if var.name.startswith("encoder")]
        self.G_variable = [var for var in tf.trainable_variables() if var.name.startswith("generator")]
        self.D_id_variable = [var for var in tf.trainable_variables() if var.name.startswith("discriminator_id")]
        self.D_img_variable = [var for var in tf.trainable_variables() if var.name.startswith("discriminator_img")]

        self.D_id_loss = -tf.reduce_mean(tf.log(self.logits_true_for_did) + tf.log(1.0 - self.logits_false_for_did))
        self.D_img_loss = -tf.reduce_mean(tf.log(self.logits_true_for_dimg) + tf.log(1.0 - self.logits_false_for_dimg))
        self.EG_loss = -tf.reduce_mean(tf.log(self.logits_true_for_g_id)) + tf.reduce_mean(
            tf.losses.absolute_difference(
                self.input_real_image, self.generated_img))  - tf.reduce_mean(tf.log(self.logits_true_for_g_img))

        self.D_id_optimizer = tf.train.AdamOptimizer(self.learning_rate * 0.05, self.beta1)
        self.D_id_grads_and_vars = self.D_id_optimizer.compute_gradients(self.D_id_loss, var_list=self.D_id_variable)
        self.D_id_train = self.D_id_optimizer.apply_gradients(self.D_id_grads_and_vars)

        self.D_img_optimizer = tf.train.AdamOptimizer(self.learning_rate * 0.05, self.beta1)
        self.D_img_grads_and_vars = self.D_img_optimizer.compute_gradients(self.D_img_loss,
                                                                           var_list=self.D_img_variable)
        self.D_img_train = self.D_img_optimizer.apply_gradients(self.D_img_grads_and_vars)

        self.EG_optimizer = tf.train.AdamOptimizer(self.learning_rate, self.beta1)
        self.EG_grads_and_vars = self.EG_optimizer.compute_gradients(self.EG_loss,
                                                                     var_list=[self.E_variable, self.G_variable])
        self.EG_train = self.EG_optimizer.apply_gradients(self.EG_grads_and_vars)

        self.d_id_loss_sum = tf.summary.scalar('D_loss_id', self.D_id_loss)
        self.d_img_loss_sum = tf.summary.scalar('D_loss_img', self.D_img_loss)
        self.sum_eg_loss = tf.summary.scalar('EG_loss', self.EG_loss)
        self.sum_degree_0 = tf.summary.image('degree_0', self.input)
        self.sum_degree_45 = tf.summary.image('degree_45', self.input_real_image)
        self.sum_faked = tf.summary.image('faked', self.generated_img)

        self.summary_op = tf.summary.merge([self.sum_degree_0, self.sum_degree_45, self.sum_faked, self.sum_eg_loss])

    def encoder(self, input, reuse=False):
        with tf.variable_scope('encoder'):
            current = input
            current = tf.layers.conv2d(inputs=current, filters=32, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv1',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn1')

            current = tf.layers.conv2d(inputs=current, filters=64, kernel_size=(5, 5), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv2',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn2')

            current = tf.layers.conv2d(inputs=current, filters=128, kernel_size=(5, 5), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv3',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn3')

            current = tf.layers.conv2d(inputs=current, filters=256, kernel_size=(3, 3), strides=(1, 2), padding='SAME',
                                       use_bias=False, reuse=reuse, name='e_conv4',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['E_CONV4'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='e_bn4')

            current = tf.reshape(current, (-1, self.GEI_height / 8 * self.GEI_width / 16 * 256))
            current = tf.contrib.layers.fully_connected(current, 128, reuse=reuse, scope='encoder')

            return current

    def generator(self, input, k, reuse=False):
        with tf.variable_scope('generator'):
            current = tf.concat([input, k], axis=-1)
            current = tf.contrib.layers.fully_connected(current, self.GEI_height / 8 * self.GEI_width / 16 * 256,
                                                        reuse=reuse)
            current = self.lrelu(current)
            current = tf.reshape(current, (-1, self.GEI_height / 8, self.GEI_width / 16, 256))
            current = tf.layers.conv2d_transpose(inputs=current, filters=128, kernel_size=(4, 4), strides=(1, 2),
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv1',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn1')

            current = self.lrelu(current)

            current = tf.layers.conv2d_transpose(inputs=current, filters=64, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv2',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn2')

            current = self.lrelu(current)
            current = tf.layers.conv2d_transpose(inputs=current, filters=32, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv3',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='g_bn3')

            current = self.lrelu(current)
            current = tf.layers.conv2d_transpose(inputs=current, filters=1, kernel_size=(4, 4), strides=2,
                                                 padding='SAME',
                                                 use_bias=False, reuse=reuse, name='g_deconv4',
                                                 kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['G_DECONV4'] = current
            # current = tf.layers.batch_normalization(current, reuse=reuse)
            #
            # current = tf.layers.conv2d_transpose(inputs=current, filters=1, kernel_size=(4, 4), strides=2,
            #                                      padding='SAME',
            #                                      use_bias=False, reuse=reuse)
            # self.endpoints['G_DECONV5'] = current
            current = tf.nn.tanh(current)
            return current

    def discriminator_id(self, input, target, reuse=False):
        with tf.variable_scope('discriminator_id'):
            current = tf.concat([input, target], axis=3)

            current = tf.layers.conv2d(inputs=current, filters=32, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='did_conv1',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV1'] = current
            current = self.lrelu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='did_bn1')

            current = tf.layers.conv2d(inputs=current, filters=64, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='did_conv2',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV2'] = current
            current = self.lrelu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='did_bn2')

            current = tf.layers.conv2d(inputs=current, filters=128, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='did_conv3',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV3'] = current
            current = self.lrelu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='did_bn3')

            current = tf.layers.conv2d(inputs=current, filters=256, kernel_size=(7, 7), strides=(1, 2), padding='SAME',
                                       use_bias=False, reuse=reuse, name='did_conv4',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV4'] = current
            current = self.lrelu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='did_bn4')

            current = tf.reshape(current, (-1, self.GEI_height / 8 * self.GEI_width / 16 * 256))
            current = tf.contrib.layers.fully_connected(current, 1, reuse=reuse, scope='did_fc')
            current = tf.sigmoid(current)

            return current

    def discriminator_img(self, input, angle, reuse=False):
        with tf.variable_scope('discriminator_img'):
            current = input
            current = tf.layers.conv2d(inputs=current, filters=32, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv1',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV1'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn1')
            current = self.lrelu(current)

            current = self.concat_label(current, angle)
            current = tf.layers.conv2d(inputs=current, filters=64, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv2',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV2'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn2')
            current = self.lrelu(current)

            current = tf.layers.conv2d(inputs=current, filters=128, kernel_size=(7, 7), strides=2, padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv3',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV3'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn3')
            current = self.lrelu(current)

            current = tf.layers.conv2d(inputs=current, filters=256, kernel_size=(7, 7), strides=(1, 2), padding='SAME',
                                       use_bias=False, reuse=reuse, name='d_conv4',
                                       kernel_initializer=tf.random_normal_initializer(stddev=0.02))
            self.endpoints['D_CONV4'] = current
            current = tf.layers.batch_normalization(current, reuse=reuse, name='d_bn4')
            current = self.lrelu(current)

            current = tf.reshape(current, (-1, self.GEI_height / 8 * self.GEI_width / 16 * 256))
            current = tf.contrib.layers.fully_connected(current, 1, reuse=reuse, scope='dimg_fc')
            current = tf.sigmoid(current)

            return current

    def discriminator_z(self, z, reuse=True):
        with tf.variable_scope('discriminator_z'):
            current = z

            current = tf.contrib.layers.fully_connected(current, 64, scope='dz_fc1')
            current = tf.nn.relu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='dz_bn1')

            current = tf.contrib.layers.fully_connected(current, 32, scope='dz_fc2')
            current = tf.nn.relu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='dz_bn2')

            current = tf.contrib.layers.fully_connected(current, 16, scope='dz_fc3')
            current = tf.nn.relu(current)
            current = tf.layers.batch_normalization(current, reuse=reuse, name='dz_bn3')

            current = tf.contrib.layers.fully_connected(current, 1, scope='dz_fc4')

            current = tf.nn.sigmoid(current)
            return current

    def lrelu(self, x, alpha=0.2):
        return tf.nn.relu(x) - alpha * tf.nn.relu(-x)

    def concat_label(self, x, label, duplicate=1):
        x_shape = x.get_shape().as_list()
        if duplicate < 1:
            return x
        label = tf.tile(label, [1, duplicate])
        label_shape = label.get_shape().as_list()
        if len(x_shape) == 2:
            return tf.concat(axis=1, values=[x, label])
        elif len(x_shape) == 4:
            label = tf.reshape(label, [x_shape[0], 1, 1, label_shape[-1]])
            return tf.concat(axis=3, values=[x, label * tf.ones([x_shape[0], x_shape[1], x_shape[2], label_shape[-1]])])

    def train(self, ratio):
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            logdir = dir_gen.dir_gen('./summary')
            self.summary_writer = tf.summary.FileWriter(graph=sess.graph, logdir=logdir)
            self.saver = tf.train.Saver()
            data_reader = DataReader.DataReader()
            for step in range(self.max_step):
                k = int(round(step/2000.0))
                x, y = data_reader.nextBatch(self.batch_size, k)
                x = np.expand_dims(np.array(x), -1)
                y = np.expand_dims(np.array(y), -1)
                angle = np.zeros((self.batch_size,14))
                angle[:, k+1] = 1
                angle = angle.astype(float)
                for j in range(ratio):
                    _, loss_Did, sum = sess.run([self.D_id_train, self.D_id_loss, self.d_id_loss_sum],
                                              feed_dict={self.input: x, self.input_real_image: y, self.input_label:angle})
                    print("Step: %d\t Loss_D_id: %lf\n" % (step, loss_Did))
                    self.summary_writer.add_summary(sum, step * ratio + j)

                    _, loss_Dimg, sum = sess.run([self.D_img_train, self.D_img_loss, self.d_img_loss_sum],
                                                 feed_dict={self.input: x, self.input_real_image: y,
                                                            self.input_label: angle})
                    print("Step: %d\t Loss_D_id: %lf\n" % (step, loss_Did))
                    self.summary_writer.add_summary(sum, step * ratio + j)

                _, loss_EG, sum = sess.run([self.EG_train, self.EG_loss, self.summary_op],
                                           feed_dict={self.input: x, self.input_real_image: y, self.input_label:angle})
                print("Step: %d\t Loss_EG: %lf\n" % (step, loss_EG))
                self.summary_writer.add_summary(sum, step)

                # test_x = data_reader.getTestSample()
                # test_x = np.expand_dims(np.array(test_x), -1)
                # test_x = np.expand_dims(np.array(test_x), 0)
                # test_generated = sess.run(self.generated_img, feed_dict={self.input: test_x})
                # if not os.path.exists('./generated'):
                #     os.makedirs('./generated')
                # test_path = "./generated/%05d.jpg" % step
                # test_generated = np.squeeze(test_generated, 0)
                # test_generated = np.squeeze(test_generated, -1)
                # scipy.misc.imsave(test_path, test_generated)
                if (step + 1) % 500 == 0:
                    if not os.path.exists('./model'):
                        os.makedirs('./model')
                    self.saver.save(sess=sess, save_path='./model/GaitGAN', global_step=step)


if __name__ == '__main__':
    model = GaitGAN()
    # model.concat_label(model.input_real_image, model.input_label)
    model.train(1)
