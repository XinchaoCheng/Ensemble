import numpy as np
from PIL import Image
import scipy.io as sio
from os import listdir
from os.path import isfile, join, exists


class DataReader():
    def __init__(self):
        self.name = 'Data Reader'
        self.x_data_path = './GEI/000-00/'
        self.y_data_path = ['./GEI/015-00/', './GEI/030-00/', './GEI/045-00/', './GEI/060-00/', './GEI/075-00/',
                            './GEI/090-00/']
        self.x_filelist = [f for f in listdir(self.x_data_path) if isfile(join(self.x_data_path, f))]
        self.y_filelist = [f for f in listdir(self.x_data_path) if isfile(join(self.x_data_path, f))]
        self.x_size = len(self.x_filelist)
        self.y_size = len(self.y_filelist)

    def nextBatch(self, batch_size, k):
        x = []
        y = []
        local_path = self.y_data_path[k]
        for i in range(batch_size):

            index_x = np.random.randint(0, self.x_size)
            filename = self.x_filelist[index_x]

            while not exists(join(local_path, filename)):
                index_x = np.random.randint(0, self.x_size)
                filename = self.x_filelist[index_x]

            x_ = Image.open(self.x_data_path + filename)
            x_ = np.array(x_).transpose([1, 0]) / 255.0
            y_ = Image.open(local_path + filename)
            y_ = np.array(y_).transpose([1, 0]) / 255.0
            x.append(x_)
            y.append(y_)
        return [x, y]

    def getTestSample(self):
        x_ = Image.open('./GEI/test/' + '00729.png')
        x_ = np.array(x_).transpose([1, 0]) / 255.0

        return x_
    # def getTestSample(self, path):
    #     x = Image.open(path)
    #     x = np.array(x.resize((self.image_height, self.image_width), Image.ANTIALIAS))
    #     return [x]
    #
    # def getNextFakeXY(self, batch_size):
    #     faked_blurred_image = []
    #     faked_clear_image = []
    #     for i in range(batch_size):
    #         faked_blurred_image.append(np.random.randint(1, 10, (1920, 1080, 3)) / 10.0)
    #         faked_clear_image.append(np.random.randint(1, 10, (1920, 1080, 3)) / 10.0)
    #     return [faked_blurred_image, faked_clear_image]
